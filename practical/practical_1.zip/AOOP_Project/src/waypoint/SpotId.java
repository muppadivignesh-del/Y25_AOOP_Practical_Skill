package waypoint;

public record SpotId(String value) {
}