package waypoint;

public record PlateNumber(String value) {
}