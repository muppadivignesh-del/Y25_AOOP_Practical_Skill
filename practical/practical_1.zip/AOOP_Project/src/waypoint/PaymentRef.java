package waypoint;

public record PaymentRef(String value) {
}