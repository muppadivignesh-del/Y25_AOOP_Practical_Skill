package waypoint;

import java.time.Instant;

public class Ticket {

    private final TicketId ticketId;
    private final SpotId spotId;
    private final PlateNumber plateNumber;
    private final Instant entryTime;
    private Money fare;
    private PaymentRef paymentRef;
    private Instant exitTime;
    private Instant closedAt;

    private String status = "ACTIVE";

    public Ticket(TicketId ticketId, SpotId spotId,
                  PlateNumber plateNumber, Instant entryTime) {

        this.ticketId = ticketId;
        this.spotId = spotId;
        this.plateNumber = plateNumber;
        this.entryTime = entryTime;
    }

    public void completePayment(Money fare,
                                PaymentRef paymentRef,
                                Instant exitTime) {

        this.fare = fare;
        this.paymentRef = paymentRef;
        this.exitTime = exitTime;
        this.status = "PAID";
    }

    public void close(Instant closedAt) {
        this.closedAt = closedAt;
        this.status = "CLOSED";
    }

    public TicketId getTicketId() {
        return ticketId;
    }

    public SpotId getSpotId() {
        return spotId;
    }

    public PlateNumber getPlateNumber() {
        return plateNumber;
    }

    public Instant getEntryTime() {
        return entryTime;
    }

    public Money getFare() {
        return fare;
    }

    public PaymentRef getPaymentRef() {
        return paymentRef;
    }

    public Instant getExitTime() {
        return exitTime;
    }

    public Instant getClosedAt() {
        return closedAt;
    }

    public String getStatus() {
        return status;
    }
}