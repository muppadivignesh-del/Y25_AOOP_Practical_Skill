package waypoint;

public record Money(String value) {

    public String formatINR() {
        return "INR " + value;
    }
}