package waypoint;

import java.time.Instant;

public class Main {

    public static void main(String[] args) {

        System.out.println("================================");
        System.out.println(" PARKING TICKET MANAGEMENT");
        System.out.println("================================");

        // 1. Create Ticket
        Ticket ticket = new Ticket(
                new TicketId("T-101"),
                new SpotId("L2-17"),
                new PlateNumber("TS09AB1234"),
                Instant.parse("2026-11-03T09:00:00Z")
        );

        System.out.println("\n1. TICKET CREATED");
        System.out.println("Ticket ID : " + ticket.getTicketId());
        System.out.println("Spot      : " + ticket.getSpotId());
        System.out.println("Vehicle   : " + ticket.getPlateNumber());
        System.out.println("Entry     : " + ticket.getEntryTime());

        // 2. Complete Payment
        ticket.completePayment(
                new Money("150.00"),
                new PaymentRef("PAY-101"),
                Instant.parse("2026-11-03T11:00:00Z")
        );

        System.out.println("\n2. PAYMENT COMPLETED");
        System.out.println("Fare      : " + ticket.getFare().formatINR());
        System.out.println("Payment ID: " + ticket.getPaymentRef());
        System.out.println("Exit      : " + ticket.getExitTime());

        // 3. Close Ticket
        ticket.close(Instant.parse("2026-11-03T11:05:00Z"));

        System.out.println("\n3. TICKET CLOSED");
        System.out.println("Ticket ID : " + ticket.getTicketId());
        System.out.println("Spot      : " + ticket.getSpotId());
        System.out.println("Vehicle   : " + ticket.getPlateNumber());
        System.out.println("Fare      : " + ticket.getFare().formatINR());
        System.out.println("Closed At : " + ticket.getClosedAt());

        // 4. Final Ticket State
        System.out.println("\n4. FINAL TICKET STATE");
        System.out.println("Status: " + ticket.getStatus());

        System.out.println("\nProgram executed successfully!");
    }
}