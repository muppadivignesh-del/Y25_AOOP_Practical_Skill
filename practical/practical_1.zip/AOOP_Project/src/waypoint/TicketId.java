package waypoint;

public record TicketId(String value) {
}